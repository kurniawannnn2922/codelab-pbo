package kendaraan.util;

public  interface Flyable {
    //Menghapus access modifier dari method interface
    void fly();
}
